CREATE TABLE [gold].[store_dim] (

	[store_key] varchar(8000) NULL, 
	[division] varchar(8000) NULL, 
	[address] varchar(8000) NULL
);