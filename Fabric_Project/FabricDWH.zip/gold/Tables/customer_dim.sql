CREATE TABLE [gold].[customer_dim] (

	[coustomer_key] varchar(8000) NULL, 
	[name] varchar(8000) NULL, 
	[contact_no] varchar(8000) NULL, 
	[nid] varchar(8000) NULL, 
	[first_name] varchar(8000) NULL, 
	[last_name] varchar(8000) NULL
);