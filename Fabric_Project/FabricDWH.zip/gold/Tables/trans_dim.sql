CREATE TABLE [gold].[trans_dim] (

	[payment_key] varchar(8000) NULL, 
	[trans_type] varchar(8000) NULL, 
	[bank_name] varchar(8000) NULL
);