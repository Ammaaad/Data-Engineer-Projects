CREATE TABLE [gold].[fact_table] (

	[payment_key] varchar(8000) NULL, 
	[coustomer_key] varchar(8000) NULL, 
	[time_key] varchar(8000) NULL, 
	[item_key] varchar(8000) NULL, 
	[store_key] varchar(8000) NULL, 
	[quantity] int NULL, 
	[unit] varchar(8000) NULL, 
	[unit_price] int NULL, 
	[total_price] int NULL
);