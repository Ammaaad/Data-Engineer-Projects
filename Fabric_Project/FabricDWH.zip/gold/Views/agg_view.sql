-- Auto Generated (Do not modify) 31EEDEA170C2A035156B9AB46C8F70A3E66100365125C99E95518B2AB67DC157
CREATE VIEW gold.agg_view
AS
WITH outerquery
AS
(
SELECT 
    f.*,
    d.bank_name
FROM
    gold.fact_table as f
LEFT JOIN
    gold.trans_dim as d
    ON
        f.payment_key = d.payment_key)
SELECT
    bank_name,
    sum(total_price) as agg_total_price
FROM
    outerquery
GROUP BY
    bank_name